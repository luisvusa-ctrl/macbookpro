namespace CS2Cheat.Core.Data;

public enum Team
{
    Unknown = 0,
    Spectator = 1,
    Terrorists = 2,
    CounterTerrorists = 3
}